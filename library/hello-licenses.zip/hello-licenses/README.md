hello-licenses
========================

This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up for a free world. 
Adds a License to Wordpress resources such as Pages and Posts.

Clone this repository into your wp-content/plugins directory, activate it in the dashboard and you're good to go.
You may choose a License when creating/editing Pages and Posts. This information will be saved in the database as post meta data.

Developed by Rafael Trabasso & Gabriel Trabasso
